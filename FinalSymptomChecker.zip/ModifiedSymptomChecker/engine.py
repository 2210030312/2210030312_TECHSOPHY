import json

def load_symptoms():
    with open("symptoms.json") as f:
        return json.load(f)

def calculate_score(symptoms, age):
    data = load_symptoms()
    total = 0
    breakdown = []

    for s in symptoms:
        if s in data:
            base = data[s]["severity"]
            adj = base * (1.15 if age >= 30 else 1)
            total += adj
            breakdown.append((s, base, round(adj, 1)))
        else:
            breakdown.append((s, 0, 0))
    return round(total, 1), breakdown
