def get_advice(score):
    if score > 18:
        return "🚨 Critical: Visit hospital now."
    elif score > 10:
        return "⚠️ See doctor this week."
    elif score > 0:
        return "😊 Monitor symptoms at home."
    else:
        return "✅ No action needed."
