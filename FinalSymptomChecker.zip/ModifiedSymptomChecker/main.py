from validator import validate_input
from engine import calculate_score
from recommender import get_advice

# Updated patient info
patient = {
    "name": "Asha",
    "age": 32,
    "symptoms": ["joint pain", "fatigue", "nausea"]
}

def main():
    is_valid, msg = validate_input(patient)
    if not is_valid:
        print("❌", msg)
        return

    score, details = calculate_score(patient["symptoms"], patient["age"])
    advice = get_advice(score)

    print(f"\n🩺 Report for {patient['name']} (Age: {patient['age']})")
    print("Symptoms:", patient["symptoms"])
    print("Scoring:")
    for s, raw, adj in details:
        print(f" - {s}: {raw} ➝ {adj}")
    print(f"Total Score: {score}")
    print("📌 Advice:", advice)

if __name__ == "__main__":
    main()
