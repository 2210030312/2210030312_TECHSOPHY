def validate_input(data):
    if not data.get("symptoms") or not isinstance(data["symptoms"], list):
        return False, "Invalid symptoms list."
    if not isinstance(data.get("age"), int):
        return False, "Age must be an integer."
    return True, ""
